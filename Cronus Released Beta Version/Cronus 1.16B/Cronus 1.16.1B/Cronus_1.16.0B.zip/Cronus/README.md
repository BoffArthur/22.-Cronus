# Cronus
This program works based on Excel and should be used as Add-In. All of the code was written by Arthur Boff.

All archives here presented are part of Cronus and should not be freely modified. All improvements and suggestions are welcome, just let us know.

For more information about,  please send an e-mail to the system administrator: Arthur.Boff@voestalpine.com
