Mestre de Materiais Revisão 04:

The Cronus Programs: 

    C ontrol
    R esource
    O nto
 Dy n amic
  A u tomation
    S ystem 



New:

    1. Foram alterados todos os nomes dos arquivos. Feito isto com intuito de padronizar os nomes para que add-in em diversas máquinas seja possivel de funcionar

To do:

    1.

And Beyond:

    1.