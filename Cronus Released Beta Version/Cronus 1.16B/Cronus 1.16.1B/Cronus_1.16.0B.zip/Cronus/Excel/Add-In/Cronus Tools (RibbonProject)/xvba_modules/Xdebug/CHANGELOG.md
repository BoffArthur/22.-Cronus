# Changelog
## Xdebug (Under Construction)

- This package provides a way to simulate VBA Immediate Window in Output VSCode window
    
## [1.0.0b0] - 2020-09-16
### Added
 - Create XDebug.printx 
  - Create XDebug.printError 


 
 