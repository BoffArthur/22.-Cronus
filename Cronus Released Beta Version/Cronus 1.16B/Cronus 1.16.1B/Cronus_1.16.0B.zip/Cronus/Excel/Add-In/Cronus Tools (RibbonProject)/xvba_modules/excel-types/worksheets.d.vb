'/*
'A collection of all the Worksheet objects in the specified or active workbook. Each Worksheet object represents a worksheet.
'
'Example
'
'Worksheets(1).Visible = False
'
'*/
Public Class Worksheets() 

'/*
'Constructor 
'
'*/
Public  Sub New(Name As String) As Worksheet

End Sub

Public Sub Add() 

End Sub


Public Sub Add2() 

End Sub

Public Sub Copy() 

End Sub

Public Sub Delete() 
End Sub

Public Sub Move()

End Sub

Public Sub FillAcrossSheets() 

End Sub

Public Sub PrintOut() 

End Sub

Public Sub PrintPreview() 
End Sub

Public Sub Select()

End Sub  

End Class